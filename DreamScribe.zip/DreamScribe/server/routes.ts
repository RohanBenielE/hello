import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertSleepLogSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all sleep logs
  app.get("/api/sleep-logs", async (_req, res) => {
    try {
      const logs = await storage.getAllSleepLogs();
      res.json(logs);
    } catch (error) {
      console.error("Error fetching sleep logs:", error);
      res.status(500).json({ error: "Failed to fetch sleep logs" });
    }
  });

  // Get single sleep log
  app.get("/api/sleep-logs/:id", async (req, res) => {
    try {
      const log = await storage.getSleepLog(req.params.id);
      if (!log) {
        return res.status(404).json({ error: "Sleep log not found" });
      }
      res.json(log);
    } catch (error) {
      console.error("Error fetching sleep log:", error);
      res.status(500).json({ error: "Failed to fetch sleep log" });
    }
  });

  // Create new sleep log
  app.post("/api/sleep-logs", async (req, res) => {
    try {
      const validatedData = insertSleepLogSchema.parse(req.body);
      const log = await storage.createSleepLog(validatedData);
      res.status(201).json(log);
    } catch (error) {
      console.error("Error creating sleep log:", error);
      if (error instanceof Error && error.name === "ZodError") {
        return res.status(400).json({ error: "Invalid sleep log data" });
      }
      res.status(500).json({ error: "Failed to create sleep log" });
    }
  });

  // Delete sleep log
  app.delete("/api/sleep-logs/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteSleepLog(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: "Sleep log not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting sleep log:", error);
      res.status(500).json({ error: "Failed to delete sleep log" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
