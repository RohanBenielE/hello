import { type User, type InsertUser, type SleepLog, type InsertSleepLog } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getAllSleepLogs(): Promise<SleepLog[]>;
  getSleepLog(id: string): Promise<SleepLog | undefined>;
  createSleepLog(log: InsertSleepLog): Promise<SleepLog>;
  deleteSleepLog(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private sleepLogs: Map<string, SleepLog>;

  constructor() {
    this.users = new Map();
    this.sleepLogs = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getAllSleepLogs(): Promise<SleepLog[]> {
    const logs = Array.from(this.sleepLogs.values());
    return logs.sort((a, b) => {
      const dateA = new Date(a.createdAt || a.date);
      const dateB = new Date(b.createdAt || b.date);
      return dateB.getTime() - dateA.getTime();
    });
  }

  async getSleepLog(id: string): Promise<SleepLog | undefined> {
    return this.sleepLogs.get(id);
  }

  async createSleepLog(insertLog: InsertSleepLog): Promise<SleepLog> {
    const id = randomUUID();
    const log: SleepLog = {
      ...insertLog,
      id,
      dreamTags: insertLog.dreamTags || null,
      dreamEntry: insertLog.dreamEntry || null,
      location: insertLog.location || null,
      createdAt: new Date(),
    };
    this.sleepLogs.set(id, log);
    return log;
  }

  async deleteSleepLog(id: string): Promise<boolean> {
    return this.sleepLogs.delete(id);
  }
}

export const storage = new MemStorage();
