import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { WakeUpMessage } from "@/components/WakeUpMessage";
import { SleepInputCards } from "@/components/SleepInputCards";
import { SleepHistory } from "@/components/SleepHistory";
import { SleepCharts } from "@/components/SleepCharts";
import { InsightsPanel } from "@/components/InsightsPanel";
import { HealthTips } from "@/components/HealthTips";
import { ThemeToggle } from "@/components/ThemeToggle";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";
import type { SleepLog } from "@shared/schema";

export default function Dashboard() {
  const { toast } = useToast();
  const [location, setLocation] = useState<string>("");
  
  const [formData, setFormData] = useState({
    bedtime: "",
    wakeTime: "",
    quality: 7,
    exercised: false,
    caffeineIntake: 0,
    stressLevel: 3,
    dreamEntry: "",
  });

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation(`${position.coords.latitude.toFixed(2)}, ${position.coords.longitude.toFixed(2)}`);
        },
        () => {
          setLocation("Location unavailable");
        }
      );
    }
  }, []);

  const { data: logs = [], isLoading } = useQuery<SleepLog[]>({
    queryKey: ["/api/sleep-logs"],
  });

  const createLogMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("POST", "/api/sleep-logs", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sleep-logs"] });
      toast({
        title: "Sleep log saved!",
        description: "Your sleep data has been recorded successfully.",
      });
      setFormData({
        bedtime: "",
        wakeTime: "",
        quality: 7,
        exercised: false,
        caffeineIntake: 0,
        stressLevel: 3,
        dreamEntry: "",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save sleep log. Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteLogMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("DELETE", `/api/sleep-logs/${id}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sleep-logs"] });
      toast({
        title: "Log deleted",
        description: "Sleep log has been removed.",
      });
    },
  });

  const handleFormChange = (field: string, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = () => {
    const today = new Date().toISOString().split('T')[0];
    
    createLogMutation.mutate({
      date: today,
      bedtime: formData.bedtime,
      wakeTime: formData.wakeTime,
      quality: formData.quality,
      exercised: formData.exercised ? 1 : 0,
      caffeineIntake: formData.caffeineIntake,
      stressLevel: formData.stressLevel,
      dreamEntry: formData.dreamEntry || undefined,
      location: location || undefined,
    });
  };

  const latestLog = logs.length > 0 ? logs[0] : undefined;

  return (
    <div className="min-h-screen bg-background">
      <div className="sticky top-0 z-50 bg-background/80 backdrop-blur-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <h1 className="text-2xl font-serif font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            DreamRest
          </h1>
          <ThemeToggle />
        </div>
      </div>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <WakeUpMessage 
            sleepQuality={latestLog?.quality} 
            location={location}
          />
        </motion.div>

        <section>
          <h2 className="text-2xl font-semibold mb-6">Log Your Sleep</h2>
          <SleepInputCards
            formData={formData}
            onFormChange={handleFormChange}
            onSubmit={handleSubmit}
            isSubmitting={createLogMutation.isPending}
          />
        </section>

        {logs.length > 0 && (
          <>
            <section>
              <SleepCharts logs={logs} />
            </section>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <h2 className="text-2xl font-semibold mb-6">Sleep History</h2>
                {isLoading ? (
                  <div className="text-center py-12 text-muted-foreground">Loading...</div>
                ) : (
                  <SleepHistory 
                    logs={logs} 
                    onDelete={(id) => deleteLogMutation.mutate(id)} 
                  />
                )}
              </div>

              <div className="space-y-6">
                <InsightsPanel logs={logs} />
                <HealthTips />
              </div>
            </div>
          </>
        )}
      </main>
    </div>
  );
}
