import { motion } from "framer-motion";
import { Cloud, Sun, CloudRain, CloudSnow, Wind } from "lucide-react";
import { Card } from "@/components/ui/card";

interface WakeUpMessageProps {
  sleepQuality?: number;
  location?: string;
}

export function WakeUpMessage({ sleepQuality, location }: WakeUpMessageProps) {
  const hour = new Date().getHours();
  const greeting =
    hour < 12
      ? "Good morning"
      : hour < 18
      ? "Good afternoon"
      : "Good evening";

  const getMessage = () => {
    if (!sleepQuality) {
      return "Ready to track another night of rest?";
    }
    if (sleepQuality >= 8) {
      return "You had an excellent sleep! Keep it up!";
    }
    if (sleepQuality >= 6) {
      return "Good rest! A few tweaks could make it even better.";
    }
    return "Let's work on improving your sleep tonight.";
  };

  const weatherIcons = [Sun, Cloud, CloudRain, CloudSnow, Wind];
  const WeatherIcon = weatherIcons[Math.floor(Math.random() * weatherIcons.length)];

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="relative overflow-hidden rounded-3xl p-8 md:p-12 border-0 shadow-lg">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-accent/10 to-background opacity-50" />
        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex-1 text-center md:text-left">
            <h1 className="text-4xl md:text-5xl font-light font-serif mb-3 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent" data-testid="text-greeting">
              {greeting}
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed" data-testid="text-message">
              {getMessage()}
            </p>
            {location && (
              <p className="text-sm text-muted-foreground mt-2" data-testid="text-location">
                {location}
              </p>
            )}
          </div>
          <div className="flex items-center justify-center w-20 h-20 md:w-24 md:h-24 rounded-full bg-gradient-to-br from-primary/30 to-accent/30">
            <WeatherIcon className="w-10 h-10 md:w-12 md:h-12 text-primary" />
          </div>
        </div>
      </Card>
    </motion.div>
  );
}
