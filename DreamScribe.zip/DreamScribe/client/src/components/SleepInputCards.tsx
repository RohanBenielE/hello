import { Moon, Activity, Cloud } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { VoiceRecorder } from "./VoiceRecorder";
import { motion } from "framer-motion";

interface SleepInputCardsProps {
  formData: {
    bedtime: string;
    wakeTime: string;
    quality: number;
    exercised: boolean;
    caffeineIntake: number;
    stressLevel: number;
    dreamEntry: string;
  };
  onFormChange: (field: string, value: any) => void;
  onSubmit: () => void;
  isSubmitting: boolean;
}

export function SleepInputCards({ formData, onFormChange, onSubmit, isSubmitting }: SleepInputCardsProps) {
  const getQualityLabel = (quality: number) => {
    if (quality <= 3) return "Poor";
    if (quality <= 5) return "Fair";
    if (quality <= 7) return "Good";
    if (quality <= 9) return "Great";
    return "Excellent";
  };

  const getStressLabel = (stress: number) => {
    const labels = ["Very Low", "Low", "Moderate", "High", "Very High"];
    return labels[stress - 1];
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 },
  };

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="grid grid-cols-1 md:grid-cols-3 gap-6"
    >
      {/* Sleep Card */}
      <motion.div variants={cardVariants}>
        <Card className="rounded-2xl shadow-lg border-card-border h-full">
          <CardHeader className="space-y-1 pb-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                <Moon className="w-5 h-5 text-primary" />
              </div>
              <CardTitle className="text-lg">Sleep</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="bedtime" className="text-sm font-medium">
                Bedtime
              </Label>
              <Input
                id="bedtime"
                type="time"
                value={formData.bedtime}
                onChange={(e) => onFormChange('bedtime', e.target.value)}
                className="rounded-xl"
                data-testid="input-bedtime"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="wakeTime" className="text-sm font-medium">
                Wake Time
              </Label>
              <Input
                id="wakeTime"
                type="time"
                value={formData.wakeTime}
                onChange={(e) => onFormChange('wakeTime', e.target.value)}
                className="rounded-xl"
                data-testid="input-waketime"
              />
            </div>

            <div className="space-y-3">
              <Label className="text-sm font-medium">
                Sleep Quality: {getQualityLabel(formData.quality)}
              </Label>
              <div className="flex items-center gap-3">
                <span className="text-xs text-muted-foreground w-8">Poor</span>
                <Slider
                  value={[formData.quality]}
                  onValueChange={(value) => onFormChange('quality', value[0])}
                  min={1}
                  max={10}
                  step={1}
                  className="flex-1"
                  data-testid="slider-quality"
                />
                <span className="text-xs text-muted-foreground w-8">Great</span>
              </div>
              <p className="text-center text-sm font-medium text-primary">{formData.quality}/10</p>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Lifestyle Card */}
      <motion.div variants={cardVariants}>
        <Card className="rounded-2xl shadow-lg border-card-border h-full">
          <CardHeader className="space-y-1 pb-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                <Activity className="w-5 h-5 text-primary" />
              </div>
              <CardTitle className="text-lg">Lifestyle</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <Label htmlFor="exercised" className="text-sm font-medium">
                Exercised today?
              </Label>
              <Switch
                id="exercised"
                checked={formData.exercised}
                onCheckedChange={(checked) => onFormChange('exercised', checked)}
                data-testid="switch-exercised"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="caffeine" className="text-sm font-medium">
                Caffeine intake (cups)
              </Label>
              <Input
                id="caffeine"
                type="number"
                min={0}
                max={10}
                value={formData.caffeineIntake}
                onChange={(e) => onFormChange('caffeineIntake', parseInt(e.target.value) || 0)}
                className="rounded-xl"
                data-testid="input-caffeine"
              />
            </div>

            <div className="space-y-3">
              <Label className="text-sm font-medium">
                Stress Level: {getStressLabel(formData.stressLevel)}
              </Label>
              <div className="flex items-center gap-3">
                <span className="text-xs text-muted-foreground w-8">Low</span>
                <Slider
                  value={[formData.stressLevel]}
                  onValueChange={(value) => onFormChange('stressLevel', value[0])}
                  min={1}
                  max={5}
                  step={1}
                  className="flex-1"
                  data-testid="slider-stress"
                />
                <span className="text-xs text-muted-foreground w-8">High</span>
              </div>
              <p className="text-center text-sm font-medium text-primary">{formData.stressLevel}/5</p>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Dream Card */}
      <motion.div variants={cardVariants}>
        <Card className="rounded-2xl shadow-lg border-card-border h-full">
          <CardHeader className="space-y-1 pb-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                <Cloud className="w-5 h-5 text-primary" />
              </div>
              <CardTitle className="text-lg">Dream Journal</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="dreamEntry" className="text-sm font-medium">
                What did you dream?
              </Label>
              <Textarea
                id="dreamEntry"
                value={formData.dreamEntry}
                onChange={(e) => onFormChange('dreamEntry', e.target.value)}
                placeholder="Describe your dreams..."
                className="min-h-[120px] rounded-xl resize-none"
                data-testid="textarea-dream"
              />
            </div>

            <div className="pt-2 border-t">
              <VoiceRecorder
                onTranscript={(text) => {
                  const newEntry = formData.dreamEntry
                    ? `${formData.dreamEntry} ${text}`
                    : text;
                  onFormChange('dreamEntry', newEntry);
                }}
              />
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Submit Button */}
      <motion.div variants={cardVariants} className="md:col-span-3">
        <Button
          onClick={onSubmit}
          disabled={isSubmitting || !formData.bedtime || !formData.wakeTime}
          className="w-full rounded-full px-8 py-6 text-lg font-semibold shadow-lg"
          data-testid="button-submit-log"
        >
          {isSubmitting ? "Saving..." : "Save Sleep Log"}
        </Button>
      </motion.div>
    </motion.div>
  );
}
