import { Lightbulb } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useEffect, useState } from "react";

const healthTips = [
  "Aim for 7-9 hours of sleep each night for optimal health.",
  "Keep your bedroom cool (60-67°F) for better sleep quality.",
  "Avoid screens 1 hour before bedtime to improve melatonin production.",
  "Establish a consistent sleep schedule, even on weekends.",
  "Create a relaxing bedtime routine to signal your body it's time to sleep.",
  "Limit caffeine intake after 2 PM to avoid sleep disruption.",
  "Exercise regularly, but not within 3 hours of bedtime.",
  "Keep your bedroom dark and quiet for uninterrupted sleep.",
  "Avoid large meals and alcohol close to bedtime.",
  "Try meditation or deep breathing exercises to reduce stress.",
  "Invest in a comfortable mattress and pillows for better rest.",
  "Use your bed only for sleep to strengthen the sleep association.",
  "If you can't sleep after 20 minutes, get up and do a quiet activity.",
  "Morning sunlight exposure helps regulate your circadian rhythm.",
  "Keep a dream journal to improve dream recall and self-awareness.",
];

export function HealthTips() {
  const [currentTip, setCurrentTip] = useState("");

  useEffect(() => {
    const dayOfYear = Math.floor((Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) / 86400000);
    setCurrentTip(healthTips[dayOfYear % healthTips.length]);
  }, []);

  return (
    <Card className="rounded-xl shadow-md border-card-border max-w-sm">
      <CardHeader className="pb-3">
        <div className="flex items-center gap-2">
          <Lightbulb className="w-5 h-5 text-primary" />
          <CardTitle className="text-base">Daily Tip</CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-sm leading-relaxed text-muted-foreground" data-testid="text-health-tip">
          {currentTip}
        </p>
      </CardContent>
    </Card>
  );
}
