import { motion } from "framer-motion";
import { Moon, Activity, Cloud, Trash2 } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type { SleepLog } from "@shared/schema";

interface SleepHistoryProps {
  logs: SleepLog[];
  onDelete: (id: string) => void;
}

export function SleepHistory({ logs, onDelete }: SleepHistoryProps) {
  const calculateDuration = (bedtime: string, wakeTime: string) => {
    const [bedHour, bedMin] = bedtime.split(':').map(Number);
    const [wakeHour, wakeMin] = wakeTime.split(':').map(Number);
    
    let bedMinutes = bedHour * 60 + bedMin;
    let wakeMinutes = wakeHour * 60 + wakeMin;
    
    if (wakeMinutes < bedMinutes) {
      wakeMinutes += 24 * 60;
    }
    
    const durationMinutes = wakeMinutes - bedMinutes;
    const hours = Math.floor(durationMinutes / 60);
    const minutes = durationMinutes % 60;
    
    return `${hours}h ${minutes}m`;
  };

  const getQualityColor = (quality: number) => {
    if (quality >= 8) return "bg-green-500/20 text-green-700 dark:text-green-400";
    if (quality >= 6) return "bg-yellow-500/20 text-yellow-700 dark:text-yellow-400";
    return "bg-red-500/20 text-red-700 dark:text-red-400";
  };

  if (logs.length === 0) {
    return (
      <Card className="rounded-2xl shadow-lg border-card-border p-12 text-center">
        <Moon className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-50" />
        <h3 className="text-xl font-semibold mb-2">No sleep logs yet</h3>
        <p className="text-muted-foreground">Start tracking your sleep to see insights and patterns!</p>
      </Card>
    );
  }

  return (
    <div className="space-y-3">
      {logs.map((log, index) => (
        <motion.div
          key={log.id}
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: index * 0.05 }}
        >
          <Card className="rounded-xl shadow-md border-card-border hover-elevate" data-testid={`card-sleep-log-${log.id}`}>
            <CardContent className="p-4">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 space-y-2">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-semibold" data-testid={`text-date-${log.id}`}>
                      {new Date(log.date).toLocaleDateString('en-US', {
                        weekday: 'short',
                        month: 'short',
                        day: 'numeric',
                      })}
                    </span>
                    <Badge className={`${getQualityColor(log.quality)} rounded-full text-xs`} data-testid={`badge-quality-${log.id}`}>
                      {log.quality}/10
                    </Badge>
                    <span className="text-xs text-muted-foreground">
                      {calculateDuration(log.bedtime, log.wakeTime)}
                    </span>
                  </div>

                  <div className="flex items-center gap-4 text-xs text-muted-foreground flex-wrap">
                    <div className="flex items-center gap-1">
                      <Moon className="w-3 h-3" />
                      <span>{log.bedtime} - {log.wakeTime}</span>
                    </div>
                    {log.exercised === 1 && (
                      <div className="flex items-center gap-1">
                        <Activity className="w-3 h-3" />
                        <span>Exercised</span>
                      </div>
                    )}
                    {log.caffeineIntake > 0 && (
                      <span>Caffeine: {log.caffeineIntake} cup{log.caffeineIntake > 1 ? 's' : ''}</span>
                    )}
                  </div>

                  {log.dreamEntry && (
                    <div className="flex items-start gap-2 pt-2 border-t">
                      <Cloud className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                      <p className="text-sm text-muted-foreground line-clamp-2" data-testid={`text-dream-${log.id}`}>
                        {log.dreamEntry}
                      </p>
                    </div>
                  )}
                </div>

                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => onDelete(log.id)}
                  className="rounded-full flex-shrink-0"
                  data-testid={`button-delete-${log.id}`}
                >
                  <Trash2 className="w-4 h-4" />
                  <span className="sr-only">Delete log</span>
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  );
}
