import { Sparkles } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { motion } from "framer-motion";
import type { SleepLog } from "@shared/schema";

interface InsightsPanelProps {
  logs: SleepLog[];
}

export function InsightsPanel({ logs }: InsightsPanelProps) {
  const generateInsights = () => {
    if (logs.length === 0) {
      return [
        "Start logging your sleep to get personalized insights!",
        "Track at least 3 nights to see patterns emerge.",
      ];
    }

    const insights: string[] = [];
    const recent = logs.slice(-7);
    
    const avgQuality = recent.reduce((sum, log) => sum + log.quality, 0) / recent.length;
    const avgStress = recent.reduce((sum, log) => sum + log.stressLevel, 0) / recent.length;
    const avgCaffeine = recent.reduce((sum, log) => sum + log.caffeineIntake, 0) / recent.length;
    const exerciseCount = recent.filter(log => log.exercised === 1).length;

    if (avgQuality >= 8) {
      insights.push("Your sleep quality is excellent! Keep maintaining your current routine.");
    } else if (avgQuality >= 6) {
      insights.push("Your sleep quality is good, but there's room for improvement.");
    } else {
      insights.push("Your sleep quality could be better. Let's identify what's affecting it.");
    }

    if (avgStress > 3.5) {
      insights.push("High stress levels detected. Try relaxation techniques before bed.");
    }

    if (avgCaffeine > 2) {
      insights.push("Consider reducing caffeine intake, especially after 2 PM.");
    }

    if (exerciseCount >= 4) {
      insights.push("Great job exercising regularly! It's helping your sleep quality.");
    } else if (exerciseCount < 2) {
      insights.push("Regular exercise can significantly improve sleep quality.");
    }

    const withDreams = recent.filter(log => log.dreamEntry && log.dreamEntry.length > 10).length;
    if (withDreams >= 3) {
      insights.push("You're actively recording dreams! This helps track your REM sleep.");
    }

    return insights;
  };

  const insights = generateInsights();

  return (
    <Card className="rounded-2xl shadow-lg border-card-border">
      <CardHeader className="pb-3">
        <div className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-primary" />
          <CardTitle className="text-lg">Sleep Insights</CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <ul className="space-y-3">
          {insights.map((insight, index) => (
            <motion.li
              key={index}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className="flex items-start gap-2"
            >
              <span className="text-primary mt-1">•</span>
              <span className="text-sm leading-relaxed" data-testid={`text-insight-${index}`}>{insight}</span>
            </motion.li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
}
