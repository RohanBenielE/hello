import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const sleepLogs = pgTable("sleep_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  date: text("date").notNull(),
  bedtime: text("bedtime").notNull(),
  wakeTime: text("wake_time").notNull(),
  quality: integer("quality").notNull(),
  exercised: integer("exercised").notNull().default(0),
  caffeineIntake: integer("caffeine_intake").notNull().default(0),
  stressLevel: integer("stress_level").notNull().default(3),
  dreamEntry: text("dream_entry"),
  dreamTags: text("dream_tags").array(),
  location: text("location"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertSleepLogSchema = createInsertSchema(sleepLogs).omit({
  id: true,
  createdAt: true,
}).extend({
  quality: z.number().min(1).max(10),
  exercised: z.number().min(0).max(1),
  caffeineIntake: z.number().min(0),
  stressLevel: z.number().min(1).max(5),
  dreamEntry: z.string().optional(),
  dreamTags: z.array(z.string()).optional(),
  location: z.string().optional(),
});

export type InsertSleepLog = z.infer<typeof insertSleepLogSchema>;
export type SleepLog = typeof sleepLogs.$inferSelect;

// Remove users table as we don't need authentication for this app
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
